import 'package:app/global_resource.dart';

class AbsensiServices extends GetConnect implements GetxService {
  final box = GetStorage();

  Future<Response> hadirPost(body) {
    var tokens = box.read(Base.token);
    final header = {'Authorization': '$tokens'};
    return post(Base.url + Base.absenHadir, headers: header, body);
  }

  Future<Response> pulangPut(param, body) {
    var tokens = box.read(Base.token);
    final header = {'Authorization': '$tokens'};
    return put(
        '${Base.url}${Base.absenPulang}?id=${param['id']}&tanggal=${param['tanggal']}',
        headers: header,
        body);
  }

  Future<Response> izinPost(body) {
    var tokens = box.read(Base.token);
    final header = {'Authorization': '$tokens'};
    return post(Base.url + Base.absenIzin, headers: header, body);
  }
}
