import 'package:app/global_resource.dart';
import 'components/card_home.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(HomeController());
    return GetBuilder<HomeController>(
      init: HomeController(),
      dispose: (state) {
        state.controller!.cancelTimer();
      },
      builder: (s) => Scaffold(
        backgroundColor: Colors.white,
        resizeToAvoidBottomInset: false,
        bottomNavigationBar: customNavbar(0),
        body: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(
                  top: 50, left: 20, right: 20, bottom: 20),
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(
                        color: const Color.fromRGBO(238, 240, 244, 1),
                        width: 2),
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.white),
                child: TextFormField(
                  onTap: () {
                    Get.toNamed(RouteName.homeSearch);
                    s.dataSearch();
                  },
                  readOnly: true,
                  decoration: InputDecoration(
                      hintText: "Telusuri",
                      hintStyle: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: Colors.black),
                      contentPadding: EdgeInsets.zero,
                      prefixIcon: const Icon(
                        FeatherIcons.search,
                        color: Colors.black,
                      ),
                      suffixIcon: GestureDetector(
                        onTap: () {
                          showDialog(
                              context: context,
                              builder: (ctx) => modalSelectCompany(context, s));
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(
                              right: 10, top: 10, bottom: 10),
                          child: buildImageSizeIcon(
                              context,
                              changeUrlImage(s.perusahaan?['logoPerusahaan'] ??
                                  'wwwroot/Images/CompanyLogo/logo_hora.png')),
                        ),
                      ),
                      border: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20.0)),
                        borderSide: BorderSide(
                            color: Colors.white,
                            style: BorderStyle.none,
                            width: 0),
                      ),
                      focusedBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20.0)),
                        borderSide: BorderSide(
                            color: Colors.white,
                            style: BorderStyle.none,
                            width: 0),
                      ),
                      enabledBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20.0)),
                        borderSide: BorderSide(
                            color: Colors.white,
                            style: BorderStyle.none,
                            width: 0),
                      )),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, bottom: 20),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Daftar hadir (${s.absen?.length})",
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      await showDatePicker(
                              locale: const Locale("id", "ID"),
                              context: context,
                              initialDate: DateFormat("yyyy-MM-dd hh:mm:ss")
                                  .parse(s.currentDate!),
                              firstDate: DateTime(DateTime.now().year - 10,
                                  DateTime.now().month, DateTime.now().day),
                              lastDate: DateTime(DateTime.now().year + 10,
                                  DateTime.now().month, DateTime.now().day),
                              currentDate: DateTime.now(),
                              initialDatePickerMode: DatePickerMode.day)
                          .then((value) {
                        s.gantiTanggal(value);
                      });
                    },
                    style: const ButtonStyle(
                        backgroundColor: MaterialStatePropertyAll(
                            Color.fromRGBO(238, 240, 244, 1))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          FeatherIcons.calendar,
                          size: 16,
                        ),
                        const SizedBox(
                          width: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Text(
                            changeFormatDate(3, s.currentDate.toString()),
                            style: const TextStyle(fontWeight: FontWeight.w500),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
            dataHome(context, s)
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(20))),
          onPressed: () => s.absensi(context),
          label: timerCount(context, s),
          backgroundColor: s.klikAbsen ? colorGrayPrimary : colorBluePrimary,
        ),
      ),
    );
  }
}

// FloatingActionButton fabStar(BuildContext context, s) {
//   return ;
// }

// FloatingActionButton fabReset(BuildContext context, s) {
//   return FloatingActionButton.extended(
//       shape: const RoundedRectangleBorder(
//           borderRadius: BorderRadius.all(Radius.circular(20))),
//       onPressed: () async {
//         // if (canClicked) {
//         //   showDialog(
//         //       context: context,
//         //       builder: (ctx) => customDialog(
//         //           context,
//         //           "Kehadiran hari ini telah diisi. Apakah anda ingin pulang ?",
//         //           "Ok",
//         //           onTap: () => Get.back())).then((value) {
//         //     if (value) {
//         //       // ref.read(timerProvider.notifier).reset();
//         //       Get.toNamed(RouteName.absen);
//         //     }
//         //   });
//         // } else {
//         // if (await Permission.camera.isGranted &&
//         //     await Permission.location.isGranted) {
//         //   Get.toNamed(RouteName.absen);
//         // } else {
//         // showModalBottomSheet(
//         //     shape: const RoundedRectangleBorder(
//         //         borderRadius: BorderRadius.only(
//         //             topLeft: Radius.circular(20),
//         //             topRight: Radius.circular(20))),
//         //     context: context,
//         //     builder: (ctx) => const DialogPermission()).then((value) {
//         //   if (value != null) {
//         //     Get.toNamed(RouteName.absen);
//         //   }
//         // });
//         // }
//         // }
//       },
//       label: timerCount(context, s),
//       backgroundColor: colorGrayPrimary);
// }
// }
