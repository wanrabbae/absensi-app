import 'package:app/global_resource.dart';

Widget formData(s, context) {
  return Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.max,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, right: 30, bottom: 3),
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            height: 60,
            child: TextFormField(
              onChanged: (value) {
                s.otpForm = value;
                // if (value == "1234") {
                //   ref.read(prefProvider).setIsLogin(true);
                //   AppRoute.push(Routes.TUTORIAL).then((value) {
                //     ref.read(prefProvider).setIsFirstOpen(true);
                //     if (value != null) {
                //       AppRoute.push(Routes.MAIN);
                //     }
                //   });
                // } else {
                //   showDialog(
                //       context: context,
                //       builder: (ctx) => customDialog(
                //           context, "Periksa kembali kode OTP", "OK",
                //           onTap: () => AppRoute.pop()));
                // }
              },
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                  contentPadding:
                      const EdgeInsets.only(left: 20, top: 20, bottom: 20),
                  filled: true,
                  fillColor: Colors.white,
                  hintText: "Masukkan kode OTP",
                  suffixIconConstraints:
                      const BoxConstraints(minHeight: 30, minWidth: 30),
                  suffixIconColor: Colors.white,
                  suffixIcon: GestureDetector(
                    onTap: () {
                      s.otpKirim();
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(right: 20),
                      child: Image.asset(
                        "assets/icons/arrow_right_primary.png",
                        width: 30,
                        height: 30,
                      ),
                    ),
                  )),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: customTextRich(
              context, "Tidak menerima kode OTP ? ", "Kirim Ulang",
              onTextClicked: () {
            LoginController().emailKirim(s.emailForm, 1);
          }),
        )
      ],
    ),
  );
}
