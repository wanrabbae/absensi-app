import 'package:app/global_resource.dart';

Widget formData(s, context) {
  return Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.max,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 3, left: 20, right: 20),
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            height: 60,
            child: TextFormField(
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return "Anda belum memasukan alamat email";
                }
                return null;
              },
              // controller: controller,
              onChanged: (value) => s.emailForm = value,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                hintText: "Masukkan e-mail anda",
                contentPadding:
                    const EdgeInsets.only(left: 20, top: 20, bottom: 20),
                suffixIconConstraints:
                    const BoxConstraints(minHeight: 30, minWidth: 30),
                suffixIconColor: Colors.white,
                suffixIcon: GestureDetector(
                  onTap: () {
                    s.emailKirim(null, 2);
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(right: 20),
                    child: Image.asset(
                      "assets/icons/arrow_right_primary.png",
                      width: 30,
                      height: 30,
                    ),
                  ),
                ),
              ),
            ),
          ),
        )
      ],
    ),
  );
}
